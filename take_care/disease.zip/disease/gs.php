<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<link rel="stylesheet" type="text/css" href="design.css">
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>gs</title>

</head>
<body>
<div style="text-align: center; background-color: rgb(234, 198, 127); width: 100%; height: 212px;">
<div style="float: left; background-color: rgb(234, 198, 127); height: 200px; text-align: left; width: 300px;"><big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg"> </big></div>
<div style="float: right; width: 70%; margin-left: 20px; height: 212px;">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table style="text-align: left; width: 515px; margin-left: 135px;" border="0" cellpadding="0" cellspacing="0">
<tbody style="margin-left: 23px; width: 585px;">
<tr>
<td style="background-color: rgb(234, 198, 127); width: 30px; margin-left: 5px;">
<a href="home.php" target="_top"><button class="btnExample" type="submit" value="home"><font weight="bold" size="4">home</font></button></a>
</td>
<td> <a href="gallery.php" target="_top"><button
 class="btnExample" type="submit" value="gallery"><font
 weight="bold" size="4">gallery</font></button></a></td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<br>
<div style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 790px; color: rgb(102, 51, 0);"><br>
<div style="text-align: center; font-weight: bold;"><big>
Central Government Health Scheme</big></div>
<br>
The CGHS (Central Government Health Scheme) started in 1954, with its
headquarters at New Delhi. Its main objective is to provide
comprehensive medical care to the Central Government employees that
incorporate - both serving and pensioners including their dependent
family members. <br>
<br>
<div style="text-align: center;"><img style="width: 250px; height: 250px;" alt="cghs" src="CGHS.jpg"></div>
<span style="font-weight: bold;">Central Government Health
Scheme:</span><br>
In India, the CGHS (Central Government Health Scheme) provides health
care facilities to beneficiaries that includes All Central Government
Servants paid through Civil Estimates, Ex-Governors and Ex-Vice
Presidents, former Prime Ministers, Judges of Supreme Court and High
Courts in India, Members of Parliament and Ex-MPs, Pensioners drawing
pension from Civil Estimates and their family members, Employees and
Pensioners of Autonomous Bodies, Former Judges of Supreme Court and
High Courts in India and Freedom Fighters. Such persons can avail
healthcare benefits under CGHS scheme.<br>
Under CGHS, diversified health services are provided through
Allopathic, Indian (Ayurveda, Yoga, Unani and Siddha) and Homeopathic
systems of medicine. The specialized treatments are provided through
various dispensaries/polyclinics across India. The CMOs (Chief medical
officers) and medical officers are in charge of the dispensaries for
the smooth functioning of the healthcare scheme.<br>
The CGHS (Central Government Health Scheme provides comprehensive
healthcare facilities for the Central Govt. employees and pensioners
including their dependents residing in cities incorporated under this
healthcare scheme.<br>
This scheme is currently operational in cities viz. Allahabad,
Ahmedabad, Bengaluru, Bhubhaneshwar, Bhopal, Chandigarh, Chennai,
Delhi, Dehradun, Guwahati, Hyderabad, Jaipur, Jabalpur, Jammu, Kanpur,
Kolkata, Lucknow, Meerut, Mumbai, Nagpur, Patna, Pune, Ranchi, Shillong
and Thiruvananthapuram. <br>
This scheme provides comprehensive healthcare facilities for the <span style="font-weight: bold; text-decoration: underline;">cancer, asthamatic and diabetic patients</span>. The medical facilities are provided through
Wellness Centres (previously referred to as CGHS Dispensaries) and
polyclinics under Allopathic, Ayurveda, Yoga, Unani, Sidha and
Homeopathic systems of medicines. The break-up of CGHS medical or
healthcare facilities across India are enlisted below:<br>
<br>
<ul>
<li>&nbsp;248 Allopathic dispensaries</li>
<li>&nbsp;19 polyclinics</li>
<li>&nbsp;Ayush dispensary/units</li>
<li>&nbsp;3 Yoga Centres</li>
<li>65 Laboratories </li>
<li>17 Dental Units</li>
</ul>
<br>
</div>
<br>
<div style="height: 250px; background-color: rgb(141, 135, 145); vertical-align: top;">
<div style="text-align: center;">
<table style="text-align: left; width: 1170px; height: 202px;" border="0" cellpadding="0" cellspacing="40">
<tbody>
<tr>
<td style="text-align: left; vertical-align: top; height: 162px; width: 345px;">&nbsp;
&nbsp; &nbsp; <img style="width: 145px; height: 100px;" alt="tc" src="pizap.com14255645944244.jpg"><br>
Our
vision is a healthy world
Formed in 1980, this Association is the world's leading voluntary
health organization in diseases care, support and research<span style="font-weight: bold;">.</span> </td>
<td style="vertical-align: top; text-align: center; height: 150px; width: 699px;">
<big style="color: white;"><big><span style="font-weight: bold;">GET SOCIAL WITH US</span></big></big><br>
<table style="width: 782px; height: 150px; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="text-align: center;"><img style="width: 100px; height: 100px;" alt="FB" src="fb-logo-grey.png"> &nbsp; &nbsp;&nbsp; <img style="width: 100px; height: 100px;" alt="T" src="twitter-logo-grey1_thumb.png"></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</body></html>