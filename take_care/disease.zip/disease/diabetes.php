<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="design.css" /><title>diabetes</title>

<script language="javascript" type="text/javascript">
var timerid = 0;
var images = new Array( "d0.jpg",
"d7.jpg",
"d6.jpg",
"d4.jpg",
"d5.jpg");
var countimages = 0;
function startTime()
{
if(timerid)
{
timerid = 0;
}
var tDate = new Date();
if(countimages == images.length)
{
countimages = 0;
}
if(tDate.getSeconds() % 5 == 0)
{
document.getElementById("img1").src = images[countimages];
}
countimages++;
timerid = setTimeout("startTime()", 700);
}
</script></head>
<body onload="startTime();">
<div style="text-align: center; background-color: rgb(234, 198, 127); width: 100%; height: 212px;">
<div style="float: left; background-color: rgb(234, 198, 127); height: 200px; text-align: left; width: 300px;"><big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg" /> </big></div>
<div style="float: right; width: 70%; margin-left: 20px; height: 212px;">
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<table style="text-align: left; width: 515px; margin-left: 135px;" border="0" cellpadding="0" cellspacing="0">
<tbody style="margin-left: 23px; width: 585px;">
<tr>
<td style="background-color: rgb(234, 198, 127); width: 30px; margin-left: 5px;">
<a href="home.php" target="_top"><button class="btnExample" type="submit" value="home"><font weight="bold" size="4">home</font></button></a>
</td>
<td> <a href="gallery.php" target="_top"><button
 class="btnExample" type="submit" value="gallery"><font
 weight="bold" size="4">gallery</font></button></a></td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<br />
<div style="width: 100%; vertical-align: top; text-align: center;">
<img style="width: 603px; height: 402px;" id="img1" src="d0.jpg" /></div>
<br />
<br />
<div style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 380px; font-weight: bold;"><span style="color: rgb(102, 51, 0);"><span style="font-weight: normal;">Diabetes can strike anyone,
from any walk of life.</span></span><br />
<span style="color: rgb(102, 51, 0);"><span style="font-weight: normal;">Diabetes is the most common
metabolic disorder affecting populations in
all geographical regions of the world. The prevalence of diabetes is
influenced by genetic, ethnic and socioeconomic factors. The World
Health Organization (WHO) has projected that the prevalence of diabetes
is increasing in epidemic proportions especially in developing
countries. India has the highest number of people with Diabetes in the
World.
<br />
And it does&nbsp;in numbers that are dramatically increasing. In the
last
decade, the cases of people living with diabetes jumped almost 50
percent – to more than 29 million Americans.&nbsp; Worldwide, it
afflicts more than 380 million people.&nbsp; And the World Health
Organizationestimates that by 2030, that number of people living with
diabetes will
more than double.&nbsp;&nbsp;&nbsp; It is a leading cause of blindness,
kidney failure, amputations, heart failure and stroke. Living with
diabetes places an
enormous emotional, physical and financial burden on the entire family.</span><br style="font-weight: normal;" />
</span><br />
<span style="font-weight: bold; color: rgb(102, 51, 0);">DIABETES TOPICS</span><br />
<span style="color: rgb(102, 51, 0);"></span>
<ul style="text-align: left; color: rgb(102, 51, 0);">
<li><a href="rd.php" target="_top">Reason and avoidance</a></li>
<li><a href="td.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Treatments&nbsp;available&nbsp;at&nbsp;Hospitals</span></a></li>
<li><span style="font-size: 12pt; font-family: 'Times New Roman';">Increasing&nbsp;costs&nbsp;of&nbsp;medicines</span></li>
<li><a href="ad.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Aids</span></a></li>
<li><span style="font-size: 12pt; font-family: 'Times New Roman';">Medical info&nbsp;</span></li>

<li><a href="gs.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Government&nbsp;Schemes</span></a></li>

</ul>
</div>
<br />
<div style="height: 250px; background-color: rgb(141, 135, 145); vertical-align: top;">
<div style="text-align: center;">
<table style="text-align: left; width: 1170px; height: 202px;" border="0" cellpadding="0" cellspacing="40">
<tbody>
<tr>
<td style="text-align: left; vertical-align: top; height: 162px; width: 345px;">
&nbsp; &nbsp; &nbsp; <img style="width: 145px; height: 100px;" alt="tc" src="pizap.com14255645944244.jpg" /><br />
Our
vision is a healthy world
Formed in 1980, this Association is the world's leading voluntary
health organization in diseases care, support and research<span style="font-weight: bold;">.</span>
</td>
<td style="vertical-align: top; text-align: center; height: 150px; width: 699px;">
<big style="color: white;"><big><span style="font-weight: bold;">GET SOCIAL WITH US</span></big></big><br />
<table style="width: 782px; height: 150px; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="text-align: center;"><img style="width: 100px; height: 100px;" alt="FB" src="fb-logo-grey.png" /> &nbsp; &nbsp;&nbsp;
<img style="width: 100px; height: 100px;" alt="T" src="twitter-logo-grey1_thumb.png" /></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</body></html>