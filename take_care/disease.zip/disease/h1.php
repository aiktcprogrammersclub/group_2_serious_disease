<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<link rel="stylesheet" type="text/css" href="design.css">
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>home</title>

</head>
<body>
<table style="text-align: center; width: 100%; height: 100%;" border="0" cellpadding="0" cellspacing="5">
<tbody>
<tr>
<td style="width: 100%; height: 230px; background-color: rgb(234, 198, 127);">
<div style="text-align: center;"></div>
<table style="text-align: left; background-color: rgb(234, 198, 127); width: 1179px; height: 212px;" border="0" cellpadding="2" cellspacing="0">
<tbody>
<tr>
<td style="width: 415px; background-color: rgb(234, 198, 127); height: 212px; text-align: center;">
<big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg"> &nbsp; &nbsp;
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
&nbsp;&nbsp; &nbsp;<br>
</big></td>
<td style="vertical-align: bottom; width: 754px; height: 212px;">
<table style="text-align: left; width: 515px; margin-left: 115px;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="background-color: rgb(234, 198, 127); width: 35px;">
<button class="btnExample" type="submit" value="home"><font weight="bold" size="4">&nbsp;home</font></button>
</td>
<td> <button class="btnExample" type="submit" value="gallery"><font weight="bold" size="4">gallery</font></button>
</td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 557px;">
<br>
<br>
<table style="width: 1138px; height: 457px; text-align: left; margin-left: auto; margin-right: auto;" border-right-color="" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; width: 430px; text-align: center;"><span style="color: rgb(102, 51, 0); font-weight: bold;"><big><br>GIVE SMILES . GIVE HOPE.<br>
<big style="color: rgb(102, 51, 0);"><br>
</big></big></span>
<div style="text-align: left;"><big style="color: rgb(102, 51, 0);">Giving someone Hope to Smile
is the best thing you can ever do in this world. Join us and be a
source of a reason behind the smile of someone &#9829;</big><br>
<br>
<br>
<br>
<br>
<br>
<br>
<div style="text-align: left;">&nbsp;
&nbsp; &nbsp;&nbsp;
<button class="btnExample2" value="LOGIN"><font weight="bold" size="4">login</font></button>&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;
<button class="btnExample2" value="REGISTER"><font weight="bold" size="4">&nbsp;
register</font></button>
</div>
</div>
<span style="color: rgb(102, 51, 0); font-weight: bold;"><big></big></span></td>
<td style="width: 702px; background-color: white;">&nbsp;
&nbsp;<img style="width: 677px; height: 431px;" alt="h" src="Top-5-Healthcare-1-1.jpg">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table style="height: 320px; text-align: left; margin-left: auto; margin-right: auto; width: 1029px;" border="0" cellpadding="0" cellspacing="30">
<tbody>
<tr>
<td style="width: 302px;"><img style="width: 300px; height: 200px;" alt="cancer" src="pediatric_cancer-300x200.jpg"></td>
<td style="width: 296px;"><img src="Diabetes-is-killing-one-patient-every-six-seconds.jpg" alt="diabetes" style="width: 300px; height: 200px;"></td>
<td style="width: 301px;"><img style="width: 300px; height: 200px;" alt="asthama" src="30-asthma.jpg"></td>
</tr>
<tr>
<td style="color: rgb(102, 51, 0); font-weight: bold; width: 302px;"><span style="font-size: 18px;">Cancer
is a class of diseases characterized by out-of-control cell growth.
There are over 100 different types of cancer, and each is classified by
the type of cell that is initially affected.<br>
<br>
<br>
<br>
</span>
<div style="text-align: center;"><span style="font-size: 18px;"></span><span style="font-size: 18px;"><button class="btnExample2" value="cancer"><font weight="bold" size="4">&nbsp;
Cancer</font></button></span></div>
</td>
<td style="width: 296px;"><b style="font-size: 18px; font-weight: bold; color: rgb(102, 51, 0);">Diabetes
mellitus,commonly referred to as diabetes, is a group of metabolic
diseases in which there are high blood
sugarlevels over a prolonged period.<br>
<br>
<br>
<br>
<br>
<br>
</b>
<div style="text-align: center;"><b style="font-size: 18px; font-weight: bold; color: rgb(102, 51, 0);"><span style="font-size: 18px;"><button class="btnExample2" value="diabetes"><font weight="bold" size="4">&nbsp;
Diabetes</font></button></span></b></div>
<b style="font-size: 18px; font-weight: bold; color: rgb(102, 51, 0);"><span style="font-size: 18px;"></span></b></td>
<td style="color: rgb(102, 51, 0); font-weight: bold; width: 301px;"><span style="font-size: 18px;">
Asthma (AZ-ma) is a chronic (long-term) lung disease that inflames and
narrows the airways. Asthma causes recurring periods of wheezing (a
whistling sound when you breathe), chest tightness, shortness of
breath, and coughing.<br>
<br>
<br>
</span>
<div style="text-align: center;"><span style="font-size: 18px;"></span><span style="font-size: 18px;"><button class="btnExample2" value="asthma"><font weight="bold" size="4">&nbsp;
Asthma</font></button></span></div>
<span style="font-size: 18px;"></span></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="height: 152px; background-color: rgb(141, 135, 145); vertical-align: top;">
<div style="text-align: center;"></div>
<table style="text-align: left; width: 100%; height: 320px;" border="0" cellpadding="0" cellspacing="40">
<tbody>
<tr>
<td style="text-align: left; vertical-align: top; height: 240px; width: 233px;">
<div style="text-align: left;"></div>
&nbsp; &nbsp; &nbsp; <img style="width: 145px; height: 100px;" alt="tc" src="pizap.com14255645944244.jpg"><br>
<big>Our
vision is a healthy world
Formed in 1980, this Association is the world's leading voluntary
health organization in diseases care, support and research</big><span style="font-weight: bold;">.</span><br style="font-weight: bold;">
<br>
</td>
<td style="vertical-align: top; text-align: center; height: 240px; width: 824px;">
<big style="color: white;"><big><span style="font-weight: bold;">GET SOCIAL WITH US</span></big></big><br>
<table style="width: 782px; height: 171px; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="text-align: center;"><img style="width: 100px; height: 100px;" alt="FB" src="fb-logo-grey.png"> &nbsp; &nbsp;&nbsp;
<img style="width: 100px; height: 100px;" alt="T" src="twitter-logo-grey1_thumb.png"></td>
</tr>
</tbody>
</table>
<br>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body></html>