<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="design.css" /><title>cancer</title>

<script language="javascript" type="text/javascript">
var timerid = 0;
var images = new Array( "1.jpg",
"2.jpg",
"3.jpg",
"4.jpg",
"5.jpg");
var countimages = 0;
function startTime()
{
if(timerid)
{
timerid = 0;
}
var tDate = new Date();
if(countimages == images.length)
{
countimages = 0;
}
if(tDate.getSeconds() % 5 == 0)
{
document.getElementById("img1").src = images[countimages];
}
countimages++;
timerid = setTimeout("startTime()", 700);
}
</script></head>
<body style="color: rgb(102, 51, 0); background-color: rgb(255, 255, 255);" onload="startTime();" alink="#990000" link="#660000" vlink="#330000">
<div style="text-align: center; background-color: rgb(234, 198, 127); width: 100%; height: 212px;">
<div style="float: left; background-color: rgb(234, 198, 127); height: 200px; text-align: left; width: 300px;"><big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg" /> </big></div>
<div style="float: right; width: 70%; margin-left: 20px; height: 212px;">
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<table style="text-align: left; width: 515px; margin-left: 135px;" border="0" cellpadding="0" cellspacing="0">
<tbody style="margin-left: 23px; width: 585px;">
<tr>
<td style="background-color: rgb(234, 198, 127); width: 30px; margin-left: 5px;">
<a href="home.php" target="_top"><button class="btnExample" type="submit" value="home"><font weight="bold" size="4">home</font></button></a>
</td>
<td> <a href="gallery.php" target="_top"><button
 class="btnExample" type="submit" value="gallery"><font
 weight="bold" size="4">gallery</font></button></a></td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<br />
<div style="width: 100%; vertical-align: top; text-align: center;">
<img style="width: 603px; height: 402px;" id="img1" src="3.jpg" /></div>
<br />
<div style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 380px; font-weight: bold;">
<span style="color: rgb(102, 51, 0); font-weight: normal; font-size: 12pt;">Cancer
is the name
given to a collection of related diseases. In all types of cancer, some
of the body’s cells begin to divide without stopping and spread into
surrounding tissues.</span><br style="color: rgb(102, 51, 0); font-weight: normal;" />
<span style="color: rgb(102, 51, 0); font-weight: normal;">Cancer
can start
almost anywhere in the human body, which is made up of trillions of
cells. Normally, human cells grow and divide to form new cells as the
body needs them. When cells grow old or become damaged, they die, and
new cells take their place.</span><br style="color: rgb(102, 51, 0); font-weight: normal;" />
<span style="color: rgb(102, 51, 0); font-weight: normal;">When
cancer
develops, however, this orderly process breaks down. As cells become
more and more abnormal, old or damaged cells survive when they should
die, and new cells form when they are not needed. These extra cells can
divide without stopping and may form growths called tumors.</span><br style="color: rgb(102, 51, 0); font-weight: normal;" />
<span style="color: rgb(102, 51, 0); font-weight: normal;">Many
cancers form
solid tumors, which are masses of tissue. Cancers of the blood, such as
leukemias, generally do not form solid tumors.</span><br style="color: rgb(102, 51, 0); font-weight: normal;" />
<span style="color: rgb(102, 51, 0); font-weight: normal;">Cancerous
tumors are
malignant, which means they can spread into, or invade, nearby tissues.
In addition, as these tumors grow, some cancer cells can break off and
travel to distant places in the body through the blood or the lymph
system and form new tumors far from the original tumor.</span><br style="color: rgb(102, 51, 0);" />
<span style="color: rgb(102, 51, 0);"><span style="font-weight: bold;"></span></span><span style="color: rgb(102, 51, 0);"><br />
<span style="font-weight: bold;">CANCER TOPICS</span></span><br />
<span style="color: rgb(102, 51, 0);"></span>
<ul style="text-align: left; color: rgb(102, 51, 0);">
<li><a href="RC.php" target="_top">Reason and avoidance</a></li>
<li><a href="tC.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Treatments&nbsp;available&nbsp;at&nbsp;Hospitals</span></a></li>
<li><a href="ic.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Increasing&nbsp;costs&nbsp;of&nbsp;medicines</span></a></li>
<li><a href="ac.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Aids</span></a></li>
<li><a href="mc.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Medicine info</span></a></li>

<li><a href="gs.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">Government&nbsp;Schemes</span></a></li>
<li><a href="nc.php" target="_top"><span style="font-size: 12pt; font-family: 'Times New Roman';">NGO’s</span></a></li>
</ul>
</div>
<br />
<div style="height: 250px; background-color: rgb(141, 135, 145); vertical-align: top;">
<div style="text-align: center;">
<table style="text-align: left; width: 1170px; height: 202px;" border="0" cellpadding="0" cellspacing="40">
<tbody>
<tr>
<td style="text-align: left; vertical-align: top; height: 162px; width: 345px;">
&nbsp; &nbsp; &nbsp; <img style="width: 145px; height: 100px;" alt="tc" src="pizap.com14255645944244.jpg" /><br />
Our
vision is a healthy world
Formed in 1980, this Association is the world's leading voluntary
health organization in diseases care, support and research<span style="font-weight: bold;">.</span>
</td>
<td style="vertical-align: top; text-align: center; height: 150px; width: 699px;">
<big style="color: white;"><big><span style="font-weight: bold;">GET SOCIAL WITH US</span></big></big><br />
<table style="width: 782px; height: 150px; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="text-align: center;"><img style="width: 100px; height: 100px;" alt="FB" src="fb-logo-grey.png" /> &nbsp; &nbsp;&nbsp;
<img style="width: 100px; height: 100px;" alt="T" src="twitter-logo-grey1_thumb.png" /></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</body></html>