<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<link rel="stylesheet" type="text/css" href="design.css">
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>mc</title>

</head>
<body>
<div style="text-align: center; background-color: rgb(234, 198, 127); width: 100%; height: 212px;">
<div style="float: left; background-color: rgb(234, 198, 127); height: 200px; text-align: left; width: 300px;"><big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg"> </big></div>
<div style="float: right; width: 70%; margin-left: 20px; height: 212px;">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table style="text-align: left; width: 515px; margin-left: 135px;" border="0" cellpadding="0" cellspacing="0">
<tbody style="margin-left: 23px; width: 585px;">
<tr>
<td style="background-color: rgb(234, 198, 127); width: 30px; margin-left: 5px;">
<a href="home.php" target="_top"><button class="btnExample" type="submit" value="home"><font weight="bold" size="4">home</font></button></a>
</td>
<td> <a href="gallery.php" target="_top"><button
 class="btnExample" type="submit" value="gallery"><font
 weight="bold" size="4">gallery</font></button></a></td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<br>
<div style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 2380px; color: rgb(102, 51, 0);">
<big style="font-weight: bold;"><br></big>
<div style="text-align: center;"><big><big style="font-weight: bold;">LIST OF CANCER DRUGS</big></big><br></div>
<table style="text-align: left; width: 1194px; height: 2265px;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top; width: 264px; height: 713px;"><big style="font-weight: bold;"><big><big>A</big></big></big><br>
<br>
Abiraterone Acetate<br>
Abitrexate (Methotrexate)<br>
Abraxane (Paclitaxel Albumin-stabilized Nanoparticle Formulation)<br>
ABVD<br>
ABVE<br>
ABVE-PC<br>
AC<br>
AC-T<br>
Adcetris (Brentuximab Vedotin)<br>
ADE<br>
Ado-Trastuzumab Emtansine<br>
Adriamycin (Doxorubicin Hydrochloride)<br>
Adrucil (Fluorouracil)<br>
Afatinib Dimaleate<br>
Afinitor (Everolimus)<br>
Aldara (Imiquimod)<br>
Aldesleukin<br>
Alemtuzumab<br>
Alimta (Pemetrexed Disodium)<br>
Aloxi (Palonosetron Hydrochloride)<br>
Ambochlorin (Chlorambucil)<br>
Amboclorin (Chlorambucil)<br>
Aminolevulinic Acid<br>
Anastrozole<br>
Aprepitant<br>
Aredia (Pamidronate Disodium)<br>
Arimidex (Anastrozole)<br>
Aromasin (Exemestane)<br>
Arranon (Nelarabine)<br>
Arsenic Trioxide<br>
Arzerra (Ofatumumab)<br>
Asparaginase Erwinia chrysanthemi
</td>
<td style="vertical-align: top; width: 208px; height: 713px;"><big style="font-weight: bold;"><big><big>E</big></big></big><br>
<br>
Efudex (Fluorouracil)<br>
Elitek (Rasburicase)<br>
Ellence (Epirubicin Hydrochloride)<br>
Eloxatin (Oxaliplatin)<br>
Eltrombopag Olamine<br>
Emend (Aprepitant)<br>
Enzalutamide<br>
Epirubicin Hydrochloride<br>
EPOCH<br>
Erbitux (Cetuximab)<br>
Eribulin Mesylate<br>
Erivedge (Vismodegib)<br>
Erlotinib Hydrochloride<br>
Erwinaze (Asparaginase Erwinia chrysanthemi)<br>
Etopophos (Etoposide Phosphate)<br>
Etoposide<br>
Etoposide Phosphate<br>
Evacet (Doxorubicin Hydrochloride Liposome)<br>
Everolimus<br>
Evista (Raloxifene Hydrochloride)<br>
Exemestane</td>
<td style="vertical-align: top; width: 223px; height: 713px;"><big><big><big><span style="font-weight: bold;">I</span></big></big></big><br>
<br>
Ibrance (Palbociclib)<br>
Ibritumomab Tiuxetan<br>
Ibrutinib<br>
ICE<br>
Iclusig (Ponatinib Hydrochloride)<br>
Idamycin (Idarubicin Hydrochloride)<br>
Idarubicin Hydrochloride<br>
Idelalisib<br>
Ifex (Ifosfamide)<br>
Ifosfamide<br>
Ifosfamidum (Ifosfamide)<br>
Imatinib Mesylate<br>
Imbruvica (Ibrutinib)<br>
Imiquimod<br>
Inlyta (Axitinib)<br>
Intron A (Recombinant Interferon Alfa-2b)<br>
Iodine 131 Tositumomab and Tositumomab<br>
Ipilimumab<br>
Iressa (Gefitinib)<br>
Irinotecan Hydrochloride<br>
Istodax (Romidepsin)<br>
Ixabepilone</td>
<td style="vertical-align: top; width: 190px; height: 713px;"><big><big><big><span style="font-weight: bold;">M</span></big></big></big><br>
<br>
Marqibo (Vincristine Sulfate Liposome)<br>
Matulane (Procarbazine Hydrochloride)<br>
Mechlorethamine Hydrochloride<br>
Megace (Megestrol Acetate)<br>
Megestrol Acetate<br>
Mekinist (Trametinib)<br>
Mercaptopurine<br>
Mesna<br>
Mesnex (Mesna)<br>
Methazolastone (Temozolomide)<br>
Methotrexate<br>
Methotrexate LPF (Methotrexate)<br>
Mexate (Methotrexate)<br>
Mexate-AQ (Methotrexate)<br>
Mitomycin C<br>
Mitoxantrone Hydrochloride<br>
Mitozytrex (Mitomycin C)<br>
MOPP<br>
Mozobil (Plerixafor)<br>
Mustargen (Mechlorethamine Hydrochloride)<br>
Mutamycin<br>
<br>
</td>
<td style="vertical-align: top; width: 155px; height: 713px;"><big><big><big><span style="font-weight: bold;">R</span></big></big></big><br>
<br>
Radium 223 Dichloride<br>
Raloxifene Hydrochloride<br>
Ramucirumab<br>
Rasburicase<br>
R-CHOP<br>
R-CVP<br>
Recombinant Human Papillomavirus (HPV) Bivalent Vaccine<br>
Recombinant Human Papillomavirus (HPV) Nonavalent Vaccine<br>
Recombinant Human Papillomavirus (HPV) Quadrivalent Vaccine<br>
Recombinant Interferon Alfa-2b<br>
Regorafenib<br>
Revlimid (Lenalidomide)<br>
Rheumatrex (Methotrexate)<br>
Rituxan (Rituximab)<br>
<br>
</td>
<td style="vertical-align: top; width: 87px; height: 713px;"><big><big><big><span style="font-weight: bold;">W</span></big></big></big><br>
<br>
Wellcovorin (Leucovorin Calcium)</td>
</tr>
<tr>
<td style="vertical-align: top; width: 264px; height: 373px;"><big style="font-weight: bold;"><big><big>B</big></big></big><br>
<br>
BEACOPP<br>
Becenum (Carmustine)<br>
Beleodaq (Belinostat)<br>
Belinostat<br>
Bendamustine Hydrochloride<br>
BEP<br>
Bevacizumab<br>
Bexarotene<br>
Bexxar (Tositumomab and I 131 Iodine Tositumomab)<br>
Bicalutamide<br>
BiCNU (Carmustine)<br>
Bleomycin<br>
Blinatumomab<br>
Blincyto (Blinatumomab)<br>
<br>
</td>
<td style="vertical-align: top; width: 208px; height: 373px;"><big style="font-weight: bold;"><big><big>F</big></big></big><br>
<br>
Fareston (Toremifene)<br>
Faslodex (Fulvestrant)<br>
FEC<br>
Femara (Letrozole)<br>
Filgrastim<br>
Fludara (Fludarabine Phosphate)<br>
Fludarabine Phosphate<br>
Fluoroplex (Fluorouracil)<br>
Fluorouracil<br>
Folex (Methotrexate)<br>
Folex PFS (Methotrexate)<br>
FOLFIRI<br>
FOLFIRI-BEVACIZUMAB<br>
FOLFIRI-CETUXIMAB<br>
FOLFIRINOX<br>
</td>
<td style="vertical-align: top; width: 223px; height: 373px;"><big><big><big><span style="font-weight: bold;">J</span></big></big></big><br>
<br>
Jakafi (Ruxolitinib Phosphate)<br>
Jevtana (Cabazitaxel)</td>
<td style="vertical-align: top; width: 190px; height: 373px;"><big><big><big><span style="font-weight: bold;">N</span></big></big></big><br>
<br>
Nanoparticle Paclitaxel (Paclitaxel Albumin-stabilized Nanoparticle
Formulation)<br>
Navelbine (Vinorelbine Tartrate)<br>
Nelarabine<br>
Neosar (Cyclophosphamide)<br>
Neupogen (Filgrastim)<br>
Nexavar (Sorafenib Tosylate)<br>
Nilotinib<br>
Nivolumab<br>
Nolvadex (Tamoxifen Citrate)<br>
Nplate (Romiplostim)</td>
<td style="vertical-align: top; width: 155px; height: 373px;"><big><big><big><span style="font-weight: bold;">S</span></big></big></big><br>
<br>
Sclerosol Intrapleural Aerosol (Talc)<br>
Siltuximab<br>
Sipuleucel-T<br>
Somatuline Depot (Lanreotide Acetate)<br>
Sorafenib Tosylate<br>
Sprycel (Dasatinib)<br>
STANFORD V<br>
Sterile Talc Powder (Talc)<br>
Steritalc (Talc)<br>
Stivarga (Regorafenib)<br>
Sunitinib Malate<br>
Sutent (Sunitinib Malate)<br>
Sylatron (Peginterferon Alfa-2b)<br>
<br>
</td>
<td style="vertical-align: top; width: 87px; height: 373px;"><big style="font-weight: bold;"><big><big>X</big></big></big><br>
<br>
Xalkori (Crizotinib)<br>
Xeloda (Capecitabine)<br>
XELIRI<br>
XELOX<br>
Xgeva (Denosumab)<br>
Xofigo (Radium 223 Dichloride)<br>
Xtandi (Enzalutamide)</td>
</tr>
<tr>
<td style="vertical-align: top; width: 264px; height: 490px;"><big style="font-weight: bold;"><big><big>C</big></big></big><br>
<br>
Cabazitaxel<br>
Cabozantinib-S-Malate<br>
CAF<br>
Campath (Alemtuzumab)<br>
Camptosar (Irinotecan Hydrochloride)<br>
Capecitabine<br>
CAPOX<br>
Carboplatin<br>
CARBOPLATIN-TAXOL<br>
Carfilzomib<br>
Carmubris (Carmustine)<br>
Carmustine<br>
Carmustine Implant<br>
Casodex (Bicalutamide)<br>
CeeNU (Lomustine)<br>
Ceritinib<br>
Cerubidine (Daunorubicin Hydrochloride)<br>
Cervarix (Recombinant HPV Bivalent Vaccine)<br>
Cetuximab<br>
Chlorambucil<br>
<br>
<br>
</td>
<td style="vertical-align: top; width: 208px; height: 490px;"><big style="font-weight: bold;"><big><big>G</big></big></big><br>
<br>
Gardasil (Recombinant HPV Quadrivalent Vaccine)<br>
Gardasil 9 (Recombinant HPV Nonavalent Vaccine)<br>
Gazyva (Obinutuzumab)<br>
Gefitinib<br>
Gemcitabine Hydrochloride<br>
GEMCITABINE-CISPLATIN<br>
GEMCITABINE-OXALIPLATIN<br>
Gemtuzumab Ozogamicin<br>
Gemzar (Gemcitabine Hydrochloride)<br>
Gilotrif (Afatinib Dimaleate)<br>
Gleevec (Imatinib Mesylate)<br>
Gliadel (Carmustine Implant)<br>
Gliadel wafer (Carmustine Implant)<br>
Glucarpidase<br>
Goserelin Acetate</td>
<td style="vertical-align: top; width: 223px; height: 490px;"><big style="font-weight: bold;"><big><big>K<br>
</big></big></big><br>
Kadcyla (Ado-Trastuzumab Emtansine)<br>
Keoxifene (Raloxifene Hydrochloride)<br>
Kepivance (Palifermin)<br>
Keytruda (Pembrolizumab)<br>
Kyprolis (Carfilzomib)</td>
<td style="vertical-align: top; width: 190px; height: 490px;"><big style="font-weight: bold;"><big><big>O</big></big></big><br>
<br>
Obinutuzumab<br>
OEPA<br>
Ofatumumab<br>
OFF<br>
Olaparib<br>
Omacetaxine Mepesuccinate<br>
Oncaspar (Pegaspargase)<br>
Ontak (Denileukin Diftitox)<br>
Opdivo (Nivolumab)<br>
OPPA<br>
Oxaliplatin</td>
<td style="vertical-align: top; width: 155px; height: 490px;"><big style="font-weight: bold;"><big><big>T</big></big></big><br>
<br>
TAC<br>
Tafinlar (Dabrafenib)<br>
Talc<br>
Tamoxifen Citrate<br>
Tarabine PFS (Cytarabine)<br>
Tarceva (Erlotinib Hydrochloride)<br>
Targretin (Bexarotene)<br>
Tasigna (Nilotinib)<br>
Taxol (Paclitaxel)<br>
Taxotere (Docetaxel)<br>
Temodar (Temozolomide)<br>
Temozolomide<br>
Temsirolimus<br>
Thalidomide<br>
Thalomid (Thalidomide)<br>
Thiotepa<br>
<br>
<br>
</td>
<td style="vertical-align: top; width: 87px; height: 490px;"><big style="font-weight: bold;"><big><big>Y</big></big></big><br>
<br>
Yervoy (Ipilimumab)</td>
</tr>
<tr>
<td style="vertical-align: top; width: 264px; height: 609px;"><big style="font-weight: bold;"><big><big>D</big></big></big><br>
<br>
Dabrafenib<br>
Dacarbazine<br>
Dacogen (Decitabine)<br>
Dactinomycin<br>
Dasatinib<br>
Daunorubicin Hydrochloride<br>
Decitabine<br>
Degarelix<br>
Denileukin Diftitox<br>
Denosumab<br>
DepoCyt (Liposomal Cytarabine)<br>
DepoFoam (Liposomal Cytarabine)<br>
Dexrazoxane Hydrochloride<br>
Docetaxel<br>
Doxil (Doxorubicin Hydrochloride Liposome)<br>
Doxorubicin Hydrochloride<br>
Doxorubicin Hydrochloride Liposome<br>
Dox-SL (Doxorubicin Hydrochloride Liposome)<br>
DTIC-Dome (Dacarbazine)</td>
<td style="vertical-align: top; width: 208px; height: 609px;"><big style="font-weight: bold;"><big><big>H</big></big></big><br>
<br>
Halaven (Eribulin Mesylate)<br>
Herceptin (Trastuzumab)<br>
HPV Bivalent Vaccine, Recombinant<br>
HPV Nonavalent Vaccine, Recombinant<br>
HPV Quadrivalent Vaccine, Recombinant<br>
Hycamtin (Topotecan Hydrochloride)<br>
Hyper-CVAD</td>
<td style="vertical-align: top; width: 223px; height: 609px;"><big style="font-weight: bold;"><big><big>L</big></big></big><br>
<br>
Lanreotide Acetate<br>
Lapatinib Ditosylate<br>
Lenalidomide<br>
Letrozole<br>
Leucovorin Calcium<br>
Leukeran (Chlorambucil)<br>
Leuprolide Acetate<br>
Levulan (Aminolevulinic Acid)<br>
Linfolizin (Chlorambucil)<br>
LipoDox (Doxorubicin Hydrochloride Liposome)<br>
Liposomal Cytarabine<br>
Lomustine<br>
Lupron (Leuprolide Acetate)<br>
Lupron Depot (Leuprolide Acetate)<br>
Lupron Depot-Ped (Leuprolide Acetate)<br>
Lupron Depot-3 Month (Leuprolide Acetate)<br>
Lupron Depot-4 Month (Leuprolide Acetate)<br>
Lynparza (Olaparib)</td>
<td style="vertical-align: top; width: 190px; height: 609px;"><big style="font-weight: bold;"><big><big>P</big></big></big><br>
<br>
Paclitaxel<br>
Paclitaxel Albumin-stabilized Nanoparticle Formulation<br>
PAD<br>
Palbociclib<br>
Palifermin<br>
Palonosetron Hydrochloride<br>
Pamidronate Disodium<br>
Panitumumab<br>
Paraplat (Carboplatin)<br>
Paraplatin (Carboplatin)<br>
Pazopanib Hydrochloride<br>
Pegaspargase<br>
Peginterferon Alfa-2b<br>
PEG-Intron (Peginterferon Alfa-2b)<br>
Pembrolizumab<br>
Pemetrexed Disodium<br>
Perjeta (Pertuzumab)<br>
Pertuzumab<br>
Platinol (Cisplatin)<br>
Platinol-AQ (Cisplatin)<br>
<br>
</td>
<td style="vertical-align: top; width: 155px; height: 609px;"><big style="font-weight: bold;"><big><big>V</big></big></big><br>
<br>
Vandetanib<br>
VAMP<br>
Vectibix (Panitumumab)<br>
VeIP<br>
Velban (Vinblastine Sulfate)<br>
Velcade (Bortezomib)<br>
Velsar (Vinblastine Sulfate)<br>
Vemurafenib<br>
VePesid (Etoposide)<br>
Viadur (Leuprolide Acetate)<br>
Vidaza (Azacitidine)<br>
Vinblastine Sulfate<br>
Vincasar PFS (Vincristine Sulfate)<br>
Vincristine Sulfate<br>
Vincristine Sulfate Liposome<br>
Vinorelbine Tartrate<br>
VIP<br>
Vismodegib<br>
Voraxaze (Glucarpidase)<br>
Vorinostat<br>
Votrient (Pazopanib Hydrochloride)<br>
</td>
<td style="vertical-align: top; width: 87px; height: 609px;"><big style="font-weight: bold;"><big><big>Z</big></big></big><br>
<br>
Zaltrap (Ziv-Aflibercept)<br>
Zelboraf (Vemurafenib)<br>
Zevalin (Ibritumomab Tiuxetan)<br>
Zinecard (Dexrazoxane Hydrochloride)<br>
Ziv-Aflibercept<br>
Zoladex (Goserelin Acetate)<br>
Zoledronic Acid<br>
Zolinza (Vorinostat)<br>
Zometa (Zoledronic Acid)<br>
Zydelig (Idelalisib)<br>
Zykadia (Ceritinib)<br>
Zytiga (Abiraterone Acetate)</td>
</tr>
</tbody>
</table>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>
<br>
<div style="height: 250px; background-color: rgb(141, 135, 145); vertical-align: top;">
<div style="text-align: center;">
<table style="text-align: left; width: 1170px; height: 202px;" border="0" cellpadding="0" cellspacing="40">
<tbody>
<tr>
<td style="text-align: left; vertical-align: top; height: 162px; width: 345px;">&nbsp;
&nbsp; &nbsp; <img style="width: 145px; height: 100px;" alt="tc" src="pizap.com14255645944244.jpg"><br>
Our
vision is a healthy world
Formed in 1980, this Association is the world's leading voluntary
health organization in diseases care, support and research<span style="font-weight: bold;">.</span> </td>
<td style="vertical-align: top; text-align: center; height: 150px; width: 699px;">
<big style="color: white;"><big><span style="font-weight: bold;">GET SOCIAL WITH US</span></big></big><br>
<table style="width: 782px; height: 150px; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="text-align: center;"><img style="width: 100px; height: 100px;" alt="FB" src="fb-logo-grey.png"> &nbsp; &nbsp;&nbsp; <img style="width: 100px; height: 100px;" alt="T" src="twitter-logo-grey1_thumb.png"></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</body></html>