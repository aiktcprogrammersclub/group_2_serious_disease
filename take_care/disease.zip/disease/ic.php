<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<link rel="stylesheet" type="text/css" href="design.css">
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>ic</title>

</head>
<body>
<div style="text-align: center; background-color: rgb(234, 198, 127); width: 100%; height: 212px;">
<div style="float: left; background-color: rgb(234, 198, 127); height: 200px; text-align: left; width: 300px;"><big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg"> </big></div>
<div style="float: right; width: 70%; margin-left: 20px; height: 212px;">
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table style="text-align: left; width: 515px; margin-left: 135px;" border="0" cellpadding="0" cellspacing="0">
<tbody style="margin-left: 23px; width: 585px;">
<tr>
<td style="background-color: rgb(234, 198, 127); width: 30px; margin-left: 5px;">
<a href="home.php" target="_top"><button class="btnExample" type="submit" value="home"><font weight="bold" size="4">home</font></button></a>
</td>
<td> <a href="gallery.php" target="_top"><button
 class="btnExample" type="submit" value="gallery"><font
 weight="bold" size="4">gallery</font></button></a></td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<br>
<div style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 600px; color: rgb(102, 51, 0);">
The Union Government(&#8217;s)
decision to decontrol prices of 108 drugs &#8212; used to treat tuberculosis,
AIDS, diabetes and heart ailments &#8212; has jacked up their prices.
In some cases, prices have seen an
unbelievable rise. The price of Glivec, an anti-cancer tablet, for
example,
has risen from Rs 8,500 to Rs 1.08 lakh. It even gives a
tabulated list of medicines with earlier prices and what it claims to
be the present prices. <br>
<br>
DNA is not the only one.<br>
<table style="padding: 0pt; border-collapse: collapse; background-color: rgb(255, 197, 140); width: 500px;" border="1">
<tbody>
<tr>
<td style="border: 0.75pt outset rgb(0, 0, 0); padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 59.2pt;" valign="center" width="78">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Brand&nbsp;Name&nbsp;of&nbsp;drug</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">&nbsp;(Company)</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: outset outset outset none; border-color: rgb(0, 0, 0) rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: 0.75pt 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 59.2pt;" valign="center" width="78">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Molecule</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: outset outset outset none; border-color: rgb(0, 0, 0) rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: 0.75pt 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 101.05pt;" valign="center" width="134">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Earlier&nbsp;Price&nbsp;as&nbsp;pe<span style="text-decoration: underline;">r</span></span><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; text-decoration: underline; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';"></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; text-decoration: underline; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">newspaper</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; text-decoration: underline; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">(Rs.)</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: outset outset outset none; border-color: rgb(0, 0, 0) rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: 0.75pt 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 101.05pt;" valign="center" width="134">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';"></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Current&nbsp;Price&nbsp;as</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">&nbsp;per</span><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; text-decoration: underline; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">newspaper</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; text-decoration: underline; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">(Rs.)</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: outset outset outset none; border-color: rgb(0, 0, 0) rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: 0.75pt 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 69.75pt;" valign="center" width="93">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Price&nbsp;verified&nbsp;by&nbsp;NPPA&nbsp;</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">from&nbsp;Delhi&nbsp;Market</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: outset outset outset none; border-color: rgb(0, 0, 0) rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: 0.75pt 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 68.8pt;">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Remarks</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
</tr>
<tr style="height: 44.25pt;">
<td style="border-style: none outset outset; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0); border-width: medium 0.75pt 0.75pt; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 59.2pt;" valign="center" width="78">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Geftinat</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">(M/s&nbsp;Natco&nbsp;Pharma)</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 59.2pt;" valign="center" width="78">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Geftinib&nbsp;250mg</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 101.05pt;" valign="center" width="134">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">5,900</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 101.05pt;" valign="center" width="134">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">11,500</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 69.75pt;" valign="center" width="93">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Rs.&nbsp;5,900</span><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">&nbsp;for&nbsp;30&nbsp;tabs,</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">batch&nbsp;no.&nbsp;700805,&nbsp;</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">mfg&nbsp;dt-&nbsp;08/2014,</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">&nbsp;exp.&nbsp;dt.&#8211;&nbsp;07/2016,</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 68.8pt;" valign="center" width="91">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Non-scheduled&nbsp;medicine</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">No&nbsp;change&nbsp;in&nbsp;price</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
</tr>
<tr>
<td style="border-style: none outset outset; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0); border-width: medium 0.75pt 0.75pt; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 59.2pt;" valign="center" width="78">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Glivec&nbsp;400mg</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">(M/s&nbsp;Novartis)</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 59.2pt;" valign="center" width="78">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Imatinib</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 101.05pt;" valign="center" width="134">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">8,500</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 101.05pt;" valign="center" width="134">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">1,08,000</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 69.75pt;" valign="center" width="93">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Rs.&nbsp;8452.38</span><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">&nbsp;for&nbsp;30&nbsp;tabs&nbsp;</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">as&nbsp;per&nbsp;Form-&nbsp;V&nbsp;dt.&nbsp;10.06.2014</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
<td style="border-style: none outset outset none; border-color: -moz-use-text-color rgb(0, 0, 0) rgb(0, 0, 0) -moz-use-text-color; border-width: medium 0.75pt 0.75pt medium; padding: 0pt; background-image: none; background-repeat: repeat; background-attachment: scroll; background-position: 0% 50%; width: 68.8pt;" valign="center" width="91">
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">Scheduled&nbsp;medicines&nbsp;</span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: normal; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">under&nbsp;DPCO,&nbsp;2013,</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
<p class="p15" style="margin-bottom: 7.5pt; margin-top: 7.5pt; text-align: justify; line-height: 15.75pt;"><span style="letter-spacing: 0pt; font-weight: bold; text-transform: none; font-style: normal; font-size: 13.5pt; font-family: 'Georgia';">No&nbsp;change&nbsp;in&nbsp;price</span><span style="font-size: 12pt; font-family: 'Times New Roman';"><o:p></o:p></span></p>
</td>
</tr>
</tbody>
</table>
<br>
Chauthi Duniya had sent its reporters to Dharamshila Cancer Hospital,
which is the second largest cancer treating hospital in Delhi and the
pharmacist there said that there has been no such notification yet. In
fact the present pricing and the reported pricing difference reveals it
all.<br>
In fact these allegations are factually incorrect because the price
notifications of anti-diabetic and cardio-vascular therapies issued by
National Pharmaceutical Pricing Authority (NPPA) on July 10, 2014, have
not been withdrawn. Till May 2014, NPPA had fixed ceiling prices of 440
scheduled drugs. Since then, ceiling prices have been fixed for
additional 49 scheduled drugs. Thus the total number of scheduled drugs
with fixed prices have increased from 440 to 489, ever since the
Narendra Modi-led Government assumed Office. This is expected to
provide financial relief to consumers by more than Rs 70 crore a year.<br>
<br>
</div>
<br>
<div style="height: 250px; background-color: rgb(141, 135, 145); vertical-align: top;">
<div style="text-align: center;">
<table style="text-align: left; width: 1170px; height: 202px;" border="0" cellpadding="0" cellspacing="40">
<tbody>
<tr>
<td style="text-align: left; vertical-align: top; height: 162px; width: 345px;">&nbsp;
&nbsp; &nbsp; <img style="width: 145px; height: 100px;" alt="tc" src="pizap.com14255645944244.jpg"><br>
Our
vision is a healthy world
Formed in 1980, this Association is the world's leading voluntary
health organization in diseases care, support and research<span style="font-weight: bold;">.</span> </td>
<td style="vertical-align: top; text-align: center; height: 150px; width: 699px;">
<big style="color: white;"><big><span style="font-weight: bold;">GET SOCIAL WITH US</span></big></big><br>
<table style="width: 782px; height: 150px; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="text-align: center;"><img style="width: 100px; height: 100px;" alt="FB" src="fb-logo-grey.png"> &nbsp; &nbsp;&nbsp; <img style="width: 100px; height: 100px;" alt="T" src="twitter-logo-grey1_thumb.png"></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</body></html>