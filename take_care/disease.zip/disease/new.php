<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
<?php include 'h2.php';
?>
<br>
<div style="width: 100%; background-color: rgb(255, 197, 140); vertical-align: top; height: 557px;">
<br>
<br>
<table style="width: 1138px; height: 457px; text-align: left; margin-left: auto; margin-right: auto;" border-right-color="" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; width: 430px; text-align: center;"><span style="color: rgb(102, 51, 0); font-weight: bold;"><big><br>
GIVE SMILES . GIVE HOPE.<br>
<big style="color: rgb(102, 51, 0);"><br>
</big></big></span>
<div style="text-align: left;"><big style="color: rgb(102, 51, 0);">Giving someone Hope to Smile
is the best thing you can ever do in this world. Join us and be a
source of a reason behind the smile of someone &#9829;</big><br>
<br>
<br>
<br>
<br>
<br>
<br>
<div style="text-align: left;">&nbsp;
&nbsp; &nbsp;&nbsp;
<button class="btnExample2" value="LOGIN"><font weight="bold" size="4">login</font></button>&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;
<button class="btnExample2" value="REGISTER"><font weight="bold" size="4">&nbsp;
register</font></button>
</div>
</div>
<span style="color: rgb(102, 51, 0); font-weight: bold;"></span></td>
<td style="width: 702px; background-color: white;">&nbsp;
&nbsp;<img style="width: 677px; height: 431px;" alt="h" src="Top-5-Healthcare-1-1.jpg">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
<div>
<table style="height: 320px; text-align: left; margin-left: auto; margin-right: auto; width: 1029px;" border="0" cellpadding="0" cellspacing="30">
<tbody>
<tr>
<td style="width: 302px;"><img style="width: 300px; height: 200px;" alt="cancer" src="pediatric_cancer-300x200.jpg"></td>
<td style="width: 296px;"><img src="Diabetes-is-killing-one-patient-every-six-seconds.jpg" alt="diabetes" style="width: 300px; height: 200px;"></td>
<td style="width: 301px;"><img style="width: 300px; height: 200px;" alt="asthama" src="30-asthma.jpg"></td>
</tr>
<tr>
<td style="color: rgb(102, 51, 0); font-weight: bold; width: 302px;"><span style="font-size: 18px;">Cancer
is a class of diseases characterized by out-of-control cell growth.
There are over 100 different types of cancer, and each is classified by
the type of cell that is initially affected.<br>
<br>
<br>
<br>
</span>
<div style="text-align: center;"><span style="font-size: 18px;"></span><span style="font-size: 18px;"><button class="btnExample2" value="cancer"><font weight="bold" size="4">&nbsp;
Cancer</font></button></span></div>
</td>
<td style="width: 296px;"><b style="font-size: 18px; font-weight: bold; color: rgb(102, 51, 0);">Diabetes
mellitus,commonly referred to as diabetes, is a group of metabolic
diseases in which there are high blood
sugarlevels over a prolonged period.<br>
<br>
<br>
<br>
<br>
<br>
</b>
<div style="text-align: center;"><b style="font-size: 18px; font-weight: bold; color: rgb(102, 51, 0);"><span style="font-size: 18px;"><button class="btnExample2" value="diabetes"><font weight="bold" size="4">&nbsp;
Diabetes</font></button></span></b></div>
<b style="font-size: 18px; font-weight: bold; color: rgb(102, 51, 0);"><span style="font-size: 18px;"></span></b></td>
<td style="color: rgb(102, 51, 0); font-weight: bold; width: 301px;"><span style="font-size: 18px;">
Asthma (AZ-ma) is a chronic (long-term) lung disease that inflames and
narrows the airways. Asthma causes recurring periods of wheezing (a
whistling sound when you breathe), chest tightness, shortness of
breath, and coughing.<br>
<br>
<br>
</span>
<div style="text-align: center;"><span style="font-size: 18px;"></span><span style="font-size: 18px;"><button class="btnExample2" value="asthma"><font weight="bold" size="4">&nbsp;
Asthma</font></button></span></div>
<span style="font-size: 18px;"></span></td>
</tr>
</tbody>
</table>
</div>
<div style="height: 320px; background-color: rgb(141, 135, 145); vertical-align: top;">
