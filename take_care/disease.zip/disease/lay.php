<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<link href="design.css" type="text/css" rel="stylesheet"><title>Take Care</title>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
</head>
<body>
<div style="text-align: center; background-color: rgb(234, 198, 127); width: 100%; height: 212px;">
<div style="float: left; background-color: rgb(234, 198, 127); height: 200px; text-align: left; width: 300px;"><big style="font-weight: bold;"><img style="width: 307px; height: 212px;" alt="tc" src="pizap.com14255645201653.jpg"> </big></div>
<div style="float: right; width: 70%; margin-left: 20px; height: 212px;">
<br>
<br>
<br>
<br>
<br>
<br>
<br><table style="text-align: left; width: 515px; margin-left: 135px;" border="0" cellpadding="0" cellspacing="0"><tbody style="margin-left: 23px; width: 585px;"><br>
<tr>
<td style="background-color: rgb(234, 198, 127); width: 30px; margin-left: 5px;">
<button class="btnExample" type="submit" value="home"><font weight="bold" size="4">home</font></button>
</td>
<td> <button class="btnExample" type="submit" value="gallery"><font weight="bold" size="4">gallery</font></button>
</td>
<td> <button class="btnExample" type="submit" value="feedback"><font weight="bold" size="4">feedback</font></button>
</td>
<td> <button class="btnExample" type="submit" value="home"><font weight="bold" size="4">blog</font></button>
</td>
</tr>
</tbody>
</table>


<br>

<br></div>
</div>
</body></html>